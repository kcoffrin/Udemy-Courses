﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceComparison
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] employeeList = new Employee[2];
            Invoice[] invoiceList = new Invoice[2];

            invoiceList[0] = new Invoice("2222", "Nails", 10, 9.99M);
            invoiceList[1] = new Invoice("4545", "Ladder", 2, 29.99M);
            employeeList[0] = new Employee("Sara", "Jones", "555-555-5555", 45000M);
            employeeList[1] = new Employee("John", "Brown", "545-555-3456", 60000M);

            foreach (var currentPayable in invoiceList)
            {
                Console.WriteLine("Payment due: {0:C}", currentPayable.GetPaymentAmount());
            }

            foreach (var currentPayable in employeeList)
            {
                Console.WriteLine("Payment due: {0:C}", currentPayable.GetPaymentAmount());
            }
        }
    }
}
